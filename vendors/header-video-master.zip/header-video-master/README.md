Z63 Header Video
===========
Tutorial over [here](http://zerosixthree.se/create-a-responsive-header-video-with-graceful-degradation/).
Demo over [here](http://zerosixthree.se/labs/video-header/).